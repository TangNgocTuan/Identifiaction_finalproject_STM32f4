/*
 * core.c

 *
 *  Created on: Nov 3, 2018
 *      Author: Administrator
 */
#include "Tuart.h"
int vtem;
extern UART_HandleTypeDef huart2;
void SerialPrint(uint8_t *pChar)
{
	HAL_UART_Transmit(&huart2,pChar,strlen(pChar),100);
}

void SerialPrintln(uint8_t *pChar)
{
	HAL_UART_Transmit(&huart2,pChar,strlen(pChar),100);
	HAL_UART_Transmit(&huart2,"\n",1,10);
}


void SerialPrintNumln(uint32_t pNum)
{
	int t = pNum;
	itoa(t,buffer,10);
	HAL_UART_Transmit(&huart2,buffer,strlen(buffer),100);
	HAL_UART_Transmit(&huart2,"\n",1,10);
}

void SerialPrintNum(uint32_t pNum)
{
	itoa(pNum,buffer,10);
	HAL_UART_Transmit(&huart2,buffer,strlen(buffer),100);
}

void SerialPrintNumln_float(float pNum){
	vtem = pNum*1000000;
	itoa(vtem,buffer,10);
	HAL_UART_Transmit(&huart2,buffer,strlen(buffer),100);
	HAL_UART_Transmit(&huart2,"\n",1,10);
}


void SerialPrintNum_float(float pNum){
	vtem = pNum;
	itoa(vtem,buffer,10);
	HAL_UART_Transmit(&huart2,buffer,strlen(buffer),100);
}
//void double_to_char(double f,char * buffer){
//    gcvt(f,10,buffer);
//}
