/*
 * motoOUT.h
 *
 *  Created on: Dec 3, 2018
 *      Author: Administrator
 */

#ifndef MOTOOUT_H_
#define MOTOOUT_H_
#include "stm32f4xx_hal.h"
#include "Tuart.h"
double PWM(double pu);

#endif /* MOTOOUT_H_ */
