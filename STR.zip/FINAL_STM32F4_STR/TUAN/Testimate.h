
#include "Tmatrix.h"
#include "gVariable.h"
#include "stdlib.h"

extern double PHI[4][4], theta[4][4], theta_[4][4], L[4][4], P[4][4],P_[4][4], PHItran[4][4];
extern double lamda;
extern double epsilon, w, T0, a1,a2,b1,b2, d1, d2, s1, r1, q0,  q1, q2, gama,u_set, e, ek_1, ek_2;

extern double u_dk, uk_1, uk_2, uk, yk, yk_1, yk_2;
extern double temp11[4][4],temp22[4][4],eclipsea;


void Estimatefuction(double pu, double py);
