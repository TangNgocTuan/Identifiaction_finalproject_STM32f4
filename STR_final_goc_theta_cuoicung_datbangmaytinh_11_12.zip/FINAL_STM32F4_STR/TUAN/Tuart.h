/*
 * core.h
 *
 *  Created on: Nov 3, 2018
 *      Author: Administrator
 */

#ifndef CORE_CORE_H_
#define CORE_CORE_H_
#include <stdint.h>
#include "stm32f4xx_hal.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

uint8_t buffer[200];
void SerialPrint(uint8_t *pChar);
void SerialPrintNum(int pNum);
void SerialPrintln(uint8_t *pChar);
void SerialPrintNumln(uint32_t pNum);
void SerialPrintNumln_float(float pNum);
void SerialPrintNum_float(float pNum);
void Serialtest(float pNum);
#endif /* CORE_CORE_H_ */
