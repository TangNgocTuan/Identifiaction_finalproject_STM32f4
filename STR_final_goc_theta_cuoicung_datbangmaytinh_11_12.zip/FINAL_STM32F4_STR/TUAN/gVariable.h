#pragma once
// gresult chua ket qua toan cuc cua moi phep cong tru nhan ma tran
enum Matrix_size{
    greultROW = 4,
    gresultCOLLUM = 4,
    columtheta = 4
};

// use for Tmatrix.h 
enum matrixsize{
    MAX = 5,
    MIN = 5,
    gvresulRow = 4,
    gvresultColum = 4 
};

// use for Testimat
enum Testimateconst{
    PHIcolum = 1,
    PHIrow = 4,
    Prow = 4,
    Pcolumn = 4,
    Lrow = 4,
    Lcolumn = 1,
    Thetacolumn = 1,
    Thetarow = 4,
    P_init = 10000
};
static int gcol = 0, grow = 0;