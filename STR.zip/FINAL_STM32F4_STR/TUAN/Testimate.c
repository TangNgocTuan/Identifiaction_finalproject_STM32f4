#include "Testimate.h"
extern double theta_[4][4];
extern double PHItran[4][4];
double temp11[4][4],temp22[4][4];
extern double lamda;
double eclipsea = 0;
extern double yk_1, yk_2, uk_1, uk_2;
extern double P_[4][4];
extern double PHI[4][4];

void Estimatefuction(double pu, double py) {


	//SerialPrintln("start estimate");

	
	PHI[0][0] = -yk_1;
	PHI[1][0] = -yk_2;
	PHI[2][0] =  uk_1;
	PHI[3][0] =  uk_2;

    matrixTran(PHI,PHIrow,PHIcolum,PHItran); //PHI'


    matrixMutiply(PHItran,PHIcolum,PHIrow,P_,Prow,Pcolumn,temp11); //PHI' * P_

/*
    for(grow = 0; grow<PHIcolum; ++grow){
        for(gcol = 0; gcol < Pcolumn; ++gcol){
        	SerialPrintNumln_double(temp1[grow][gcol]);
        }
    }

*/
    matrixMutiply(temp11,PHIcolum,Pcolumn,PHI,PHIrow,PHIcolum,temp22);//PHI'*P_*PHI
/*
    for(grow = 0; grow<PHIcolum; ++grow){
        for(gcol = 0; gcol < PHIcolum; ++gcol){
            cout<<gresult[grow][gcol]<<" : ";
            //system("pause");
        }
    }
*/
    double vresult1 = temp22[0][0] + lamda;  //PHI'*P_*PHI + lamda



    matrixMutiply(P_,Prow,Pcolumn,PHI,PHIrow,PHIcolum,temp11); //P_*PHI

    // TEST P_*PHI
    /* for(grow = 0; grow<Prow; ++grow){
        for(gcol = 0; gcol < PHIcolum; ++gcol){
            cout<<gresult[grow][gcol]<<" : ";
            //system("pause");
        }
    }*/

    matrixMutiply(temp11,Prow,PHIcolum,PHItran,PHIcolum,PHIrow,temp22); // P_*PHI*PHI'
    /*
    for(grow = 0; grow<Prow; ++grow){
        for(gcol = 0; gcol <PHIrow; ++gcol){
            cout<<gresult[grow][gcol]<<" : ";
            //system("pause");
        }
    }
    */
    matrixMutiply(temp22,Prow,PHIrow,P_,Prow,Pcolumn,temp11);  //P_*PHI*PHI'*P_
/*
    for(grow = 0; grow<Prow; ++grow){
        for(gcol = 0; gcol <Pcolumn; ++gcol){
            cout<<gresult[grow][gcol]<<" : ";
            //system("pause");
        }
    }
*/

    for(grow = 0; grow<Prow; ++grow){                       //P_*PHI*PHI'*P_ / (lamda + PHI'*P_*PHI)
        for(gcol = 0; gcol <Pcolumn; ++gcol){
            temp11[grow][gcol] = temp11[grow][gcol]/vresult1;
            //cout<<gresult[grow][gcol]<<" : ";
            //system("pause");
        }
    }


    for(grow = 0; grow < Prow; ++ grow){ //(P_ - P_*PHI*PHI'*P_ / (lamda + PHI'*P_*PHI) )
    	for(gcol = 0; gcol < Pcolumn; ++ gcol){
    		temp22[grow][gcol] = P_[grow][gcol] - temp11[grow][gcol];
    	}
    }
/*

    for(grow = 0; grow<Prow; ++grow){
        for(gcol = 0; gcol <Pcolumn; ++gcol){
            cout<<gresult[grow][gcol]<<" : ";
            //system("pause");
        }
    }
*/

    for(grow = 0; grow < Prow; ++ grow){                    //P
        for(gcol = 0; gcol < Pcolumn; ++ gcol){
            P[grow][gcol] = temp22[grow][gcol]/lamda;
            //SerialPrintNumln_double( P[grow][gcol]);
        }
    }
    //////////////////////////////////////////////////////////////////////////////// measure e

    matrixMutiply(PHItran,PHIcolum,PHIrow,theta_,Thetarow,Thetacolumn,temp11);//PHI'*Theta_
    /*
    for (grow = 0; grow < PHIcolum; ++grow){
        for (gcol = 0; gcol < Thetacolumn; ++gcol){
            cout<<gresult[grow][gcol]<<"   "<<endl;
        }
    }
    */

   //cout<<vresult1<<"  G";
    eclipsea = py - temp11[0][0];        //PHI'*Theta_ = gresult[0][0]
//    SerialPrintNumln_double(e);
    // cout<<e<<"  E";
    //////////////////////////////////////////////////////////////////////////////// measure L

    matrixMutiply(P_,Prow,Pcolumn,PHI,PHIrow,PHIcolum,temp11); //P_*PHI

    for(grow = 0; grow < Prow; ++ grow){
        for(gcol = 0; gcol < PHIcolum; ++ gcol){
        	//SerialPrintNumln_double(temp1[grow][gcol]);
        }
    }

    for(grow = 0; grow < Prow; ++ grow){                    //L*e = (P_*PHI / (lamda + PHI'*P_*PHI))*e;
        for(gcol = 0; gcol < PHIcolum; ++ gcol){
            L[grow][gcol] = (temp11[grow][gcol]/vresult1*eclipsea);
            //cout<<L[grow][gcol]<<" : ";
        }
    }

/////////////////////////////////////////////////////////////////// Measure Theta = Theta = Theta_ + L*e;

    // above aready measure L = L*e
    for(grow = 0; grow < Thetarow; ++ grow){
           for(gcol = 0; gcol < Thetacolumn; ++ gcol){
               theta[grow][gcol] = theta_[grow][gcol]+L[grow][gcol];
               //cout<<L[grow][gcol]<<" : ";
           }
       }

    for(grow = 0; grow < Thetarow; ++ grow){
        for(gcol = 0; gcol < Thetacolumn; ++ gcol){
            theta_[grow][gcol] = theta[grow][gcol];                 // Theta_ = Theta
        }
    }
    for(grow = 0; grow < Prow; ++ grow){
        for(gcol = 0; gcol < Pcolumn; ++ gcol){
            P_[grow][gcol] = P[grow][gcol];                  //P_ = P
        }
    }
    yk_2 = yk_1;
    uk_2 = uk_1;
    yk_1 = py;
    uk_1 = pu;
		
    //SerialPrintln("end estimate");
}
