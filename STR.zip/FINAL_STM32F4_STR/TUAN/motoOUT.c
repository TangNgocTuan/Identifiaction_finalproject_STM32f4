#include "motoOUT.h"
#define COUNTER_MAX 10000
extern TIM_HandleTypeDef htim4;
static double vreturn = 0;
double PWM(double pu){
	//SerialPrintln("start pwm");
	__HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_1,0);
	if(pu>0){
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_6,GPIO_PIN_RESET); //IN3
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,GPIO_PIN_SET);
	}
	else if(pu<0){
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_6,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,GPIO_PIN_RESET);
	}

	if(pu>COUNTER_MAX){
		pu = COUNTER_MAX;
	}

	else if(pu<-COUNTER_MAX){
		pu = -COUNTER_MAX;
	}

	vreturn = pu;
	pu = abs(pu);
	__HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_1,pu);
	//SerialPrintln("end pwm");
	return vreturn;
}

