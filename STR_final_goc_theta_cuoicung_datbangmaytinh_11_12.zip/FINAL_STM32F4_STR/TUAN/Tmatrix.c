#include "Tmatrix.h"
static uint8_t c,d,k,d;
static double sum;
void matrixMutiply(double A[4][4], uint8_t m, uint8_t n, double B[4][4],uint8_t p, uint8_t q,double C[4][4])
{
	    for (c = 0; c < m; c++) {
	      for (d = 0; d < q; d++) {
	        for (k = 0; k < p; k++) {
	          sum = sum + A[c][k]*B[k][d];
	        }

	        C[c][d] = sum;
	        sum = 0;
	      }
	    }
}

void matrixTran(double A[4][4], uint8_t m, uint8_t n, double B[4][4]){
	for(c = 0; c< m; ++c){
		for(d = 0; d < n; ++d){
			B[d][c] = A[c][d];
		}
	}

}
