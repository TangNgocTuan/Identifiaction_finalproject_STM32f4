#include "Tcontroller.h"
extern double u_dk, uk_1, uk_2;
double ek;
extern double epsilon, w, T0, a1,a2,b1,b2, d1, d2, s1, r1, q0,  q1, q2, gama, ek_1, ek_2;

double UDK(double pe,double ptheta[4][4]){
	a1 = ptheta[0][0];
    a2 = ptheta[1][0];
    b1 = ptheta[2][0];
    b2 = ptheta[3][0];

    ek   = pe;
    
    if(epsilon<=1)
        d1=-2*exp(-epsilon*w*T0)*cos(w*T0*sqrt(1-epsilon*epsilon));
    else
        d1=-2*exp(-epsilon*w*T0)*cosh(w*T0*sqrt(epsilon*epsilon - 1));

    d2  =exp(-2*epsilon*w*T0);
    r1  =(b1+b2)*(a1*b1*b2-a2*b1*b1-b2*b2);
    s1  =a2*((b1+b2)*(a1*b2-a2*b1)+b2*(b1*d2-b2*d1-b2));
    q2  =s1/r1;
    q1  =a2/b2-q2*(b1/b2-a1/a2+1);
    gama = q2*b2/a2;
    q0= 1/b1*(d1+1-a1-gama);
    u_dk = q0*ek + q1*ek_1 + q2*ek_2 + (1-gama)*uk_1 +gama*uk_2;
    
    ek_2 = ek_1;
    ek_1 = ek;
	return u_dk;
}
