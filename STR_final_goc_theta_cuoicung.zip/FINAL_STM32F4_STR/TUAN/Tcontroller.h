#include "math.h"

double UDK(double pe,double ptheta[4][4]);
