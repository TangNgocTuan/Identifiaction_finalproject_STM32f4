
#ifndef TMATRIX_H_
#define TMATRIX_H_
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
void matrixMutiply(double A[4][4], uint8_t m, uint8_t n, double B[4][4],uint8_t p, uint8_t q,double C[4][4]);

void matrixTran(double A[4][4], uint8_t m, uint8_t n, double B[4][4]);
#endif
